/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'iconsax\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-heart-filled': '&#xe959;',
		'icon-Indian-Rupee-symbol': '&#xe958;',
		'icon-nft-collection-13042': '&#xe93f;',
		'icon-nft-hand-13049': '&#xe940;',
		'icon-nft-store-13048': '&#xe941;',
		'icon-nft-token-13059': '&#xe942;',
		'icon-nft-investment-13053': '&#xe943;',
		'icon-nft-token-13046': '&#xe944;',
		'icon-nft-wallet-13050': '&#xe945;',
		'icon-nft-blockchain-13054': '&#xe946;',
		'icon-nft-license-13043': '&#xe947;',
		'icon-nft-buy-sell-13038': '&#xe948;',
		'icon-nft-auction-13051-1': '&#xe949;',
		'icon-category-2': '&#xe94a;',
		'icon-arrowline-up-3': '&#xe94b;',
		'icon-arrowline-down1': '&#xe94c;',
		'icon-arrowline-right-1': '&#xe94d;',
		'icon-arrowline-left': '&#xe94e;',
		'icon-bookmark-2': '&#xe94f;',
		'icon-box-1': '&#xe950;',
		'icon-profile-tick': '&#xe951;',
		'icon-bank': '&#xe952;',
		'icon-ipfs': '&#xe953;',
		'icon-dcube': '&#xe954;',
		'icon-trush-square': '&#xe955;',
		'icon-trash': '&#xe956;',
		'icon-delete-circle': '&#xe957;',
		'icon-empty-wallet': '&#xe902;',
		'icon-call': '&#xe901;',
		'icon-cloud-off-outline': '&#xe903;',
		'icon-dots-horizontal': '&#xe904;',
		'icon-dots-vertical': '&#xe905;',
		'icon-format-list-bulleted': '&#xe906;',
		'icon-google-chrome': '&#xe907;',
		'icon-whatsapp': '&#xe908;',
		'icon-instagram': '&#xe909;',
		'icon-linkedin': '&#xe90a;',
		'icon-twitter': '&#xe90b;',
		'icon-facebook': '&#xe90c;',
		'icon-star-1': '&#xe90d;',
		'icon-star': '&#xe90e;',
		'icon-tools': '&#xe90f;',
		'icon-scanner': '&#xe910;',
		'icon-scan': '&#xe911;',
		'icon-check': '&#xe912;',
		'icon-warning-2': '&#xe913;',
		'icon-unlock': '&#xe914;',
		'icon-heart': '&#xe915;',
		'icon-document-1': '&#xe916;',
		'icon-document-upload': '&#xe917;',
		'icon-copy-success': '&#xe918;',
		'icon-copy': '&#xe919;',
		'icon-security-safe': '&#xe91a;',
		'icon-profile-circle': '&#xe91b;',
		'icon-warning-21': '&#xe91c;',
		'icon-arrow-down': '&#xe91d;',
		'icon-arrow-up-1': '&#xe91e;',
		'icon-info-circle': '&#xe91f;',
		'icon-refresh': '&#xe920;',
		'icon-add': '&#xe921;',
		'icon-more': '&#xe922;',
		'icon-close-circle': '&#xe923;',
		'icon-arrow-down-1': '&#xe924;',
		'icon-arrow-left-2': '&#xe925;',
		'icon-arrow-right-3': '&#xe926;',
		'icon-arrow-up-2': '&#xe927;',
		'icon-arrow-circle-down': '&#xe928;',
		'icon-arrow-circle-left': '&#xe929;',
		'icon-arrow-circle-right': '&#xe92a;',
		'icon-arrow-circle-up': '&#xe92b;',
		'icon-directbox-send': '&#xe92c;',
		'icon-ethereum-classic-etc': '&#xe92d;',
		'icon-polygon-matic': '&#xe92e;',
		'icon-tick-circle': '&#xe92f;',
		'icon-money-send': '&#xe930;',
		'icon-clock': '&#xe931;',
		'icon-card': '&#xe932;',
		'icon-card-pos': '&#xe933;',
		'icon-folder-add': '&#xe934;',
		'icon-setting': '&#xe935;',
		'icon-timer': '&#xe936;',
		'icon-search-normal-1': '&#xe937;',
		'icon-home': '&#xe938;',
		'icon-chart-2': '&#xe939;',
		'icon-chart-21': '&#xe93a;',
		'icon-element-2': '&#xe93b;',
		'icon-notification': '&#xe93c;',
		'icon-menu-1': '&#xe93d;',
		'icon-empty-wallet1': '&#xe93e;',
		'icon-icon': '&#xe900;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
